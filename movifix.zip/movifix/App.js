import { AppearanceProvider, useColorScheme } from 'react-native-appearance';
import {NavigationContainer,DefaultTheme,DarkTheme} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import React from 'react'
import Header from './components/Header';
import Home from './components/Home';
import Bottombar from './components/Bottombar';
import Nowplaying from './components/Nowplaying';
import Toprated from './components/Toprated';
import Lookup from './components/Lookup';
 const App=() => {
  const scheme = useColorScheme();
  const stack=createStackNavigator()
 
  return (
    <AppearanceProvider>
      <NavigationContainer theme={scheme === 'dark' ? DarkTheme : DefaultTheme}>
          <stack.Navigator headerMode={'none'}>
          <stack.Screen name=" " component={Home}/>
          <stack.Screen name="Header" component={Header}/>
          <stack.Screen name="Bottombar" component={Bottombar}/>
          <stack.Screen name="Nowplaying" component={Nowplaying}/>
          <stack.Screen name="Toprated" component={Toprated}/>
          <stack.Screen name="Lookup" component={Lookup}/>
          </stack.Navigator>
      </NavigationContainer>
     </AppearanceProvider>
  );
};
export default App