import React, { useState } from 'react'
import {View,Text,StyleSheet} from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import Icon from 'react-native-vector-icons/dist/FontAwesome'
import Nowplaying from './Nowplaying'
import Toprated from './Toprated';
import Header from './Header';
const Bottombar=({navigation})=>{
    console.log(navigation)
        const [variable,setVariable]=useState()
          const handler=(ele)=>{
            
                   if(ele=="Nowplaying"){
                       setVariable(<Nowplaying navigation={navigation}/>)
                    }
                   if(ele=="Toprated"){
                       setVariable(<Toprated navigation={navigation}/>)
                   }
                    
                       
              console.log("in the callback")
              
          }
         
        return (
           
             <View style={{flex:1}}>
            
            <View style={{flex:25,justifyContent:'center',opacity:0.8}}>
                {variable}
            </View>
           
           
            <View style={style.bottombar}>
              <View  style={{flex:1}}>
              <TouchableOpacity 
                  onPress={()=>handler("Nowplaying")}>
                  <Icon name='film' size={30} color="black" style={style.icon} />
                  <Text style={style.text}>Nowplaying</Text>
                </TouchableOpacity>
              </View>
            
             <View  style={{flex:1}}>
             <TouchableOpacity 
                 onPress={()=>handler("Toprated")}>
                 <Icon name='star-half-o' size={30} color="black" style={style.icon} />
                 <Text style={style.text}>Toprated</Text>
             </TouchableOpacity>
             </View>
            </View>
            </View>
        
            
            
        )
    }
const style=StyleSheet.create({
        bottombar:{
            
            flex:2,
            flexDirection:'row',
            
            height:10
           
         },
    text:{
       fontSize:15,
       textAlign:"center",
       marginTop:5,
       marginBottom:30
    },
    icon:{
       fontSize:20, 
       textAlign:"center",
       marginTop:10,
       
    }
})
export default Bottombar