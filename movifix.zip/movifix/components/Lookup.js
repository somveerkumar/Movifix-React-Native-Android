import React from 'react'
import {View,Text,StyleSheet,ImageBackground } from 'react-native'
import { ScrollView } from 'react-native-gesture-handler'
const Lookup=(props)=>{
   let title=props.route.params.title
   let url=props.route.params.url
   console.log(url)
   let overview=props.route.params.overview
    return(
        <ImageBackground
        style={styles.backgroundImage}
        source={{uri:url}}>
        <View style={styles.view}>
            <ScrollView>
           
            
             <View style={styles.viewstyle}>
             <Text style={styles.title}>
                {title}
            </Text>
            <Text style={styles.text}>
                 {overview}
            </Text>
             </View>
            
             </ScrollView>
        </View>
        </ImageBackground>
    )


}
const styles=StyleSheet.create({
view:{
    flex:1,
    justifyContent:'center',
    alignItems:'center'
},
backgroundImage: {
  
        flex: 1,
        resizeMode: 'cover',
        justifyContent: 'center',
        
      
    
  },
  viewstyle:{
      flex:0.3,
      marginTop:"90%",
      backgroundColor:'black',
      borderRadius:20,
      width:350,
      justifyContent:'center',
      alignItems:'center',
      padding: 10,
      elevation:20,
      shadowColor: 'red',
      shadowOffset: { width: 9, height: 12 },
    //   shadowOpacity: 0.5,
      shadowRadius: 10,
      elevation: 30,
  },
  title:{
    fontSize:20,
    color:'white'
  },
  text:{
      color:"white",
      fontSize:15,
  }
})
export default Lookup