import React, { useEffect, useState } from 'react'
import {View,Text,StyleSheet, SafeAreaView,Image,Button} from 'react-native'
import { ScrollView, TouchableHighlight, TouchableOpacity } from 'react-native-gesture-handler'
import Header from './Header';
const Nowplaying=({navigation})=>{
      const[loading,setLoading]=useState(true)
      const [data,setData]=useState([])
      
    //  var globalNavigatorProps = { navigator }
      useEffect(()=>{
        fetch("https://api.themoviedb.org/3/movie/now_playing?api_key=a07e22bc18f5cb106bfe4cc1f83ad8ed")
          .then((response)=>response.json())    
          .then((responseJson) => {
            setData(responseJson.results)
            console.log("you got "+ responseJson.results)
            setLoading(false)
          })
          .catch( error => {
              console.error("In the "+error);
            });
      },[])

      
      const searchText = (e) => {
        if(e){
          let text = e.toLowerCase()
          filteredData=[]
          data.filter((item) => {
            if(item.title.toLowerCase().match(text)){
              filteredData.push(item)
            }
            if (!text || text === '') {
             filteredData.push()
           }
           setData(filteredData)
         })}
        }
       
        
       


     if(loading){
         return(<View style={{alignItems:'center'}}><Text>loading....</Text></View>)
     }
     else{


         return(
           <View style={{flex:1}}>
            <View style={{flex:1}}>
                 <Header searchText={searchText}/>
            </View>
            <View style={{flex:9}}>
            <SafeAreaView>
            <ScrollView>
            <View >
            {
              data.map((item, index)=>{
                let url="https://image.tmdb.org/t/p/w342"+item.poster_path
                return (
                <View style={styles.view}>
                
                  
                <View style={{flexDirection:'row'}}>
                <View style={{justifyContent: 'space-evenly',}}>
                <Image style={styles.tinyLogo} source={{uri:url}}/>
                </View>
                
                <View style={{justifyContent:'space-evenly',padding:10}}>
                <View>
                <Text key = {index} style={{fontSize:20, fontWeight: "bold"}}>
                  {item.title}
                </Text>
                </View>
                <View style={{marginRight:90}}>
                <TouchableOpacity  onPress={()=>navigation.push("Lookup",{
                  title:item.title,
                  url:url,
                  overview:item.overview
                  }) }>
                    <Text>{item.overview}</Text>
                  </TouchableOpacity>
                </View>
                </View>
                </View>
                
                 
               
                </View>
                
                )
              })
            }
          </View>
          </ScrollView>
          </SafeAreaView>
          </View>  
          </View>
         )
       }
}

const styles=StyleSheet.create({
  view:{
      marginVertical:2,
      backgroundColor:'pink',
      
      
  },
  tinyLogo: {
    // width: 342,
    width:110,
    height: 200,
  },
  logo: {
    width: 66,
    height: 58,
  },
})
export default Nowplaying