import { SearchBar } from 'react-native-elements';
import React,{useState} from 'react'
const Header=(props)=> {
  
 const [search,setSearch]=useState()
 const update=(e)=>{
   setSearch(e)
  props.searchText(search)
 }
 
    return (
      <SearchBar
        placeholder="Type Here..."
        onChangeText={update}
        value={search}
      />
    );
}
export default Header