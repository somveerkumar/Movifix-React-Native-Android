import React,{useState} from 'react'
import {View,Text,StyleSheet} from 'react-native'
import Bottombar from './Bottombar';

const Home=({navigation})=>{

    return(
        <View style={styles.view3}>
            <Bottombar navigation={navigation}/>
        </View>
    )}

    const styles=StyleSheet.create({
        view3:{
            flex:1,
            justifyContent:'flex-end',
           
        }
    })
export default Home