import React, { useEffect, useState } from 'react'
import {View,Text,StyleSheet, SafeAreaView,Image} from 'react-native'
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler'
import Header from './Header';
// import Lookup from './Lookup';
const Toprated=({navigation})=>{
      const[loading,setLoading]=useState(true)
      const [data,setData]=useState([])
     
      useEffect(()=>{
        fetch("https://api.themoviedb.org/3/movie/top_rated?api_key=a07e22bc18f5cb106bfe4cc1f83ad8ed")
          .then((response)=>response.json())    
          .then((responseJson) => {
            setData(responseJson.results)
            console.log("you got "+ responseJson.results)
            setLoading(false)
          })
          .catch( error => {
              console.error("In the "+error);
            });
      },[])
      
      const searchText = (e) => {
        if(e){
          let text = e.toLowerCase()
        const filteredData=[]
         data.filter((item) => {
           if(item.title.toLowerCase().match(text)){
             filteredData.push(item)
           }
           if (!text || text === '') {
            filteredData.push(null)
          }
          setData(filteredData)
        })
        }
      else{
        setData(data)
      }}
       




     if(loading){
         return(<View style={{alignItems:'center'}}><Text>loading....</Text></View>)
     }
     else{
         return(
           <View style={{flex:1}}>
             <View style={{flex:1}}>
                 <Header searchText={searchText}/>
             </View>
             <View style={{flex:9}}>
            <SafeAreaView>
                <ScrollView>
            <View>
            
            {
              data.map((item, index)=>{
                let url="https://image.tmdb.org/t/p/original"+item.poster_path
                return (
                <View style={styles.view}>
                
                  
                <View style={{flexDirection:'row'}}>
                <View style={{justifyContent: 'space-evenly',}}>
                <Image style={styles.tinyLogo} source={{uri:url}}/>
                </View>
                <View style={{justifyContent:'space-evenly',padding:10}}>
                <View>
                <Text key = {index} style={{fontSize:20, fontWeight: "bold"}}>
                  {item.title}
                </Text>
                </View>
                <TouchableOpacity onPress={()=>{navigation.push("Lookup",{
                  title:item.title,
                  url:url,
                  overview:item.overview}) }}>
                <View style={{marginRight:90}}>
                <Text style={{fontSize:15,}}> {item.overview}</Text>
                </View>
                </TouchableOpacity>
                </View>
                </View>
                </View>)})
            }
          </View>
         </ScrollView>
          </SafeAreaView>
          </View>
          </View>
         )
       }
}

const styles=StyleSheet.create({
  view:{
      marginVertical:2,
      backgroundColor:'pink',
      
      
  },
  tinyLogo: {
    width:110,
    height: 210,
  },
  logo: {
    width: 66,
    height: 58,
  },
})
export default Toprated